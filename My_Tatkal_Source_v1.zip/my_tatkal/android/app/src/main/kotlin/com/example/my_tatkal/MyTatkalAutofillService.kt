package com.example.my_tatkal

import android.app.assist.AssistStructure
import android.service.autofill.*
import android.view.View
import android.view.autofill.AutofillId
import android.widget.RemoteViews
import android.graphics.Color
import android.os.CancellationSignal
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class MyTatkalAutofillService : AutofillService() {
  override fun onFillRequest(request: FillRequest, cancellationSignal: CancellationSignal, callback: FillCallback) {
    val structure = request.fillContexts.lastOrNull()?.structure ?: run { callback.onSuccess(null); return }
    val fields = mutableListOf<Pair<AutofillId, String>>()
    val window = structure.windowNodeCount.let { if (it > 0) structure.getWindowNodeAt(0) else null }
    if (window == null) { callback.onSuccess(null); return }
    fun walk(node: AssistStructure.ViewNode) {
      val id = node.autofillId
      val hints = node.autofillHints?.toList() ?: emptyList()
      val text = (node.hint ?: node.className ?: "").toString().lowercase()
      if (id != null) {
        val kind = when {
          hints.any { it.equals("name", true) || it.equals("personName", true) } || text.contains("name") -> "name"
          hints.any { it.equals("gender", true) } || text.contains("gender") -> "gender"
          hints.any { it.equals("age", true) } || text.contains("age") -> "age"
          else -> ""
        }
        if (kind.isNotEmpty()) fields.add(id to kind)
      }
      for (i in 0 until node.childCount) walk(node.getChildAt(i))
    }
    walk(window.rootViewNode)
    if (fields.isEmpty()) { callback.onSuccess(null); return }
    val saved = getSharedPreferences("my_tatkal_data", Context.MODE_PRIVATE).getString("passengers", "[]") ?: "[]"
    val passengers = JSONArray(saved)
    if (passengers.length() == 0) { callback.onSuccess(null); return }
    val datasets = mutableListOf<Dataset>()
    for (i in 0 until passengers.length()) {
      val p = passengers.getJSONObject(i)
      val name = p.optString("name")
      val label = if (name.isBlank()) "Saved passenger ${i+1}" else name
      val presentation = RemoteViews(packageName, android.R.layout.simple_list_item_1).apply { setTextViewText(android.R.id.text1, label) }
      val builder = Dataset.Builder(presentation)
      for ((id, kind) in fields) {
        val value = when (kind) { "name" -> p.optString("name"); "age" -> p.optInt("age").toString(); "gender" -> p.optString("gender"); else -> "" }
        if (value.isNotBlank()) builder.setValue(id, android.view.autofill.AutofillValue.forText(value))
      }
      datasets.add(builder.build())
    }
    val response = FillResponse.Builder().also { b -> datasets.forEach { b.addDataset(it) } }.build()
    callback.onSuccess(response)
  }
  override fun onSaveRequest(request: SaveRequest, callback: SaveCallback) { callback.onSuccess() }
}
