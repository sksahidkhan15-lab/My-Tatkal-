package com.example.my_tatkal

import android.content.Intent
import android.provider.Settings
import android.content.ComponentName
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
  override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
    super.configureFlutterEngine(flutterEngine)
    MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "my_tatkal/autofill").setMethodCallHandler { call, result ->
      when (call.method) {
        "savePassengers" -> {
          val json = call.argument<String>("json") ?: "[]"
          getSharedPreferences("my_tatkal_data", MODE_PRIVATE).edit().putString("passengers", json).apply()
          result.success(true)
        }
        "openAutofillSettings" -> {
          startActivity(Intent(Settings.ACTION_SETTINGS))
          result.success(true)
        }
        else -> result.notImplemented()
      }
    }
  }
}
