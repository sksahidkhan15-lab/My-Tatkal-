import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

const green = Color(0xFF16834A);
const channel = MethodChannel('my_tatkal/autofill');

void main() => runApp(const MyTatkalApp());

class MyTatkalApp extends StatelessWidget {
  const MyTatkalApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'My Tatkal', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: green), scaffoldBackgroundColor: const Color(0xFFF5FAF6), useMaterial3: true),
    home: const MainPage(),
  );
}

class Passenger {
  final String id, name, gender, berth;
  final int age;
  Passenger({required this.id, required this.name, required this.age, required this.gender, required this.berth});
  Map<String, dynamic> toJson() => {'id':id,'name':name,'age':age,'gender':gender,'berth':berth};
  factory Passenger.fromJson(Map<String,dynamic> j) => Passenger(id:j['id'],name:j['name'],age:j['age'],gender:j['gender'],berth:j['berth'] ?? 'No Preference');
}

class MainPage extends StatefulWidget { const MainPage({super.key}); @override State<MainPage> createState()=>_MainPageState(); }
class _MainPageState extends State<MainPage> {
  int tab=0; List<Passenger> passengers=[];
  final Map<String,String> journey={'train':'','from':'','to':'','date':'','class':'3A','quota':'Tatkal'};
  @override void initState(){super.initState(); _load();}
  Future<void> _load() async { final p=await SharedPreferences.getInstance(); final raw=p.getString('passengers') ?? '[]'; setState(()=>passengers=(jsonDecode(raw) as List).map((e)=>Passenger.fromJson(e)).toList()); }
  Future<void> _save() async {
    final raw=jsonEncode(passengers.map((e)=>e.toJson()).toList());
    final p=await SharedPreferences.getInstance(); await p.setString('passengers',raw);
    try { await channel.invokeMethod('savePassengers', {'json':raw}); } on PlatformException catch (_) {}
  }
  Future<void> _addPassenger() async {
    final name=TextEditingController(), age=TextEditingController(); String gender='Male', berth='No Preference';
    final result=await showDialog<Passenger>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setD)=>AlertDialog(
      title:const Text('Add Passenger'), content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:name,decoration:const InputDecoration(labelText:'Full name')),
        TextField(controller:age,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Age')),
        DropdownButtonFormField(value:gender,decoration:const InputDecoration(labelText:'Gender'),items:['Male','Female','Transgender'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>setD(()=>gender=v!)),
        DropdownButtonFormField(value:berth,decoration:const InputDecoration(labelText:'Berth preference'),items:['No Preference','Lower','Middle','Upper','Side Lower','Side Upper'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>setD(()=>berth=v!)),
      ])), actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),FilledButton(onPressed:(){final a=int.tryParse(age.text); if(name.text.trim().isEmpty||a==null||a<1||a>125)return; Navigator.pop(ctx,Passenger(id:DateTime.now().microsecondsSinceEpoch.toString(),name:name.text.trim(),age:a,gender:gender,berth:berth));},child:const Text('Save'))],
    )));
    if(result!=null){setState(()=>passengers.add(result)); await _save();}
  }
  Future<void> _editJourney() async {
    final train=TextEditingController(text:journey['train']), from=TextEditingController(text:journey['from']), to=TextEditingController(text:journey['to']);
    await showDialog(context:context,builder:(ctx)=>AlertDialog(title:const Text('Journey details'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
      TextField(controller:train,decoration:const InputDecoration(labelText:'Train number')),
      TextField(controller:from,decoration:const InputDecoration(labelText:'From station')),
      TextField(controller:to,decoration:const InputDecoration(labelText:'To station')),
      DropdownButtonFormField<String>(value:journey['class'],decoration:const InputDecoration(labelText:'Class'),items:['1A','2A','3A','3E','SL','CC','2S'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>journey['class']=v!),
      DropdownButtonFormField<String>(value:journey['quota'],decoration:const InputDecoration(labelText:'Quota'),items:['Tatkal','Premium Tatkal','General','Ladies'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>journey['quota']=v!),
    ])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),FilledButton(onPressed:(){journey['train']=train.text;journey['from']=from.text;journey['to']=to.text;Navigator.pop(ctx);setState((){});},child:const Text('Save'))]));
  }
  Future<void> _copy(String text) async {await Clipboard.setData(ClipboardData(text:text)); if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Copied')));}
  Widget _home()=>ListView(padding:const EdgeInsets.all(16),children:[_header('My Tatkal','Prepare your journey details'),const SizedBox(height:16),_tile(Icons.people,'Saved passengers','${passengers.length} passenger(s)',()=>setState(()=>tab=1)),_tile(Icons.train,'Journey details','${journey['train']!.isEmpty?'Not set':journey['train']} • ${journey['class']}',()=>setState(()=>tab=2)),_tile(Icons.flash_on,'Autofill setup','Enable My Tatkal in Android settings',_openAutofill),const SizedBox(height:14),const Text('Note: Autofill depends on whether the IRCTC page exposes compatible fields. CAPTCHA and OTP are not automated.')]);
  Widget _passengers()=>ListView(padding:const EdgeInsets.all(16),children:[_header('Passengers','Saved privately on this phone'),...passengers.map((p)=>Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text(p.name),subtitle:Text('${p.age} • ${p.gender} • ${p.berth}'),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()async{setState(()=>passengers.removeWhere((x)=>x.id==p.id));await _save();})))),OutlinedButton.icon(onPressed:_addPassenger,icon:const Icon(Icons.add),label:const Text('Add passenger'))]);
  Widget _journey()=>ListView(padding:const EdgeInsets.all(16),children:[_header('Journey','Save train and route information'),_tile(Icons.train,'Train number',journey['train']!.isEmpty?'Not set':journey['train']!,_editJourney),_tile(Icons.route,'Route','${journey['from']} → ${journey['to']}',_editJourney),_tile(Icons.event,'Class & quota','${journey['class']} • ${journey['quota']}',_editJourney),FilledButton.icon(onPressed:_editJourney,icon:const Icon(Icons.edit),label:const Text('Edit journey'))]);
  Widget _preparation()=>ListView(padding:const EdgeInsets.all(16),children:[_header('Preparation','Copy details or use Android Autofill'),FilledButton.icon(onPressed:()=>_copy(passengers.map((p)=>'${p.name}, ${p.age}, ${p.gender}, ${p.berth}').join('\n')),icon:const Icon(Icons.copy),label:const Text('Copy all passenger details')),const SizedBox(height:10),...passengers.map((p)=>Card(child:ListTile(title:Text(p.name),subtitle:Text('${p.age} • ${p.gender}'),trailing:IconButton(icon:const Icon(Icons.copy),onPressed:()=>_copy('${p.name}\n${p.age}\n${p.gender}\n${p.berth}'))))),const SizedBox(height:12),_tile(Icons.settings,'Enable Autofill','Android Settings → Passwords & accounts → Autofill service',_openAutofill),const Text('After enabling, open the IRCTC passenger form and select My Tatkal from the Android Autofill suggestion if it appears.')]);
  Widget _header(String title,String sub)=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:26,fontWeight:FontWeight.bold,color:green)),Text(sub,style:const TextStyle(color:Colors.black54))]);
  Widget _tile(IconData icon,String title,String sub,VoidCallback tap)=>Card(child:ListTile(onTap:tap,leading:Icon(icon,color:green),title:Text(title),subtitle:Text(sub),trailing:const Icon(Icons.chevron_right)));
  Future<void> _openAutofill() async {try{await channel.invokeMethod('openAutofillSettings');}catch(_){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Open Android Settings and choose My Tatkal as Autofill service.')));}}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('My Tatkal',style:TextStyle(fontWeight:FontWeight.bold)),backgroundColor:green,foregroundColor:Colors.white),body:[_home(),_passengers(),_journey(),_preparation()][tab],bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),label:'Home'),NavigationDestination(icon:Icon(Icons.people_outline),label:'Passenger'),NavigationDestination(icon:Icon(Icons.train_outlined),label:'Journey'),NavigationDestination(icon:Icon(Icons.checklist),label:'Prepare')]));
}
