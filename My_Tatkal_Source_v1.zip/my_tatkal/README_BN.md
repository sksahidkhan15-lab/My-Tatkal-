# My Tatkal — প্রাথমিক Flutter source

এটি একটি **প্রাথমিক সোর্স-কোড নমুনা**, তৈরি করা APK নয়। এতে Flutter UI, ফোনে passenger data সংরক্ষণ এবং Android AutofillService-এর একটি প্রথম implementation আছে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- IRCTC-এর ওয়েব/অ্যাপের প্রতিটি ফিল্ডে Autofill কাজ করবে—এ নিশ্চয়তা নেই। ওয়েবসাইট/অ্যাপকে Android Autofill-এর জন্য field hints দিতে হয়।
- বয়স ও gender-এর মতো custom field সব জায়গায় শনাক্ত নাও হতে পারে।
- CAPTCHA, OTP বা অন্য নিরাপত্তা ব্যবস্থা bypass করা হয় না।
- IRCTC-তে বাস্তব পরীক্ষা না করা পর্যন্ত এটিকে কার্যকর/নিশ্চিত Autofill বলা যাবে না।

## Flutter project-এ বসানোর নিয়ম
1. `flutter create my_tatkal` দিয়ে নতুন Flutter project বানাও।
2. এই ZIP-এর `pubspec.yaml` ও `lib/main.dart` দিয়ে নতুন project-এর একই ফাইল replace করো।
3. `android/app/src/main/`-এর ফাইলগুলো একই path-এ copy/merge করো। `MainActivity.kt` ও package path যদি তোমার project-এ আলাদা হয়, package name-ও মিলিয়ে নিতে হবে।
4. `flutter pub get` এবং `flutter build apk` চালাও।
5. ফোনে app install করে Passenger যোগ করো। Android Settings-এর Autofill service তালিকায় My Tatkal বেছে নাও।

এই সোর্সের Android অংশটি Android API 26+ (Android 8+) Autofill framework-এর জন্য। Build করার আগে Flutter/Android Gradle configuration মিলিয়ে নিতে হবে।
